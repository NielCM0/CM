package proyect;

import java.io.*;
import java.net.*;
import java.util.*;

public class TicketClient {
    private String serverAddress = "127.0.0.1";
    private int serverPort = 12345;

    // Base de datos simulada para almacenar los datos de las personas
    private static final Map<String, String> personDatabase = new HashMap<>();
    private static Set<String> registeredDni = new HashSet<>();

    static {
        // Cargando datos simulados
        personDatabase.put("12345678", "Díaz Rojas, Jorge Luis");
        personDatabase.put("87654321", "Martínez López, Ana María");
        personDatabase.put("11223344", "García Torres, Carlos Alberto");
        personDatabase.put("55667788", "Pérez González, Laura Isabel");
    }

    public String requestTicket(String personDni) throws IOException {
        if (!isValidDni(personDni)) {
            return "INVALID_DNI"; // DNI no tiene un formato válido
        }

        if (registeredDni.contains(personDni)) {
            return "ALREADY_REGISTERED"; // DNI ya está registrado
        }

        if (!personDatabase.containsKey(personDni)) {
            return "NOT_FOUND"; // DNI no existe en la base de datos
        }

        try (Socket socket = new Socket(serverAddress, serverPort);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("ADD:" + personDni);
            String response = in.readLine();

            if (response.equals("SUCCESS")) {
                registeredDni.add(personDni); // Guardar el DNI como registrado
                return "SUCCESS:" + personDatabase.get(personDni);
            } else {
                return "FULL"; // Cola llena
            }
        }
    }

    private boolean isValidDni(String dni) {
        // Validar si el DNI tiene exactamente 8 dígitos numéricos
        return dni.matches("\\d{8}");
    }
}
